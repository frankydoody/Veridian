---
name: Executive Synthetic Intelligence
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-meta:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system projects authority, high-velocity synthesis, and executive precision. Designed for leadership teams, product directors, and cross-functional operators, it reframes business meetings from ephemeral audio into an immutable, structured decision graph. 

The aesthetic is anchored in **Modern Technical Glass & Obsidian Precision**: an uncompromising deep slate-navy canvas layered with crisp structural boundaries, micro-fluorescent telemetry accents, and analytical clarity. The emotional atmosphere evokes an elite control room: calm, highly observant, and vigilant against organizational misalignment.

Visual cues lean on razor-sharp typography, high-density data summaries, subtle optical flares in AI synthesis states, and unmistakable amber/vermilion conflict warnings that command attention without inducing alarm fatigue.

## Colors

The palette establishes a high-contrast executive hierarchy against an abyssal blue-gray base (`#0B0F19`), eliminating visual glare while maintaining strict WCAG AAA contrast ratios.

- **Primary (`#6366F1` - Electric Indigo):** Anchors operational interactions, focused states, verified decisions, and primary forward paths.
- **Secondary (`#A855F7` - Neural Violet):** Reserved strictly for autonomous AI operations: live speech synthesis, auto-summarization, smart task extraction, and executive audio processing.
- **Tertiary (`#F59E0B` - Kinetic Amber):** Dedicated to contradiction intelligence, conflicting consensus alerts, divergent action items, and cross-meeting friction.
- **Neutral Surface Palette:**
  - `canvas`: `#0B0F19` (Obsidian Slate)
  - `surface-elevated-1`: `#111827` (Card / Section Base)
  - `surface-elevated-2`: `#1E293B` (Interactions, Modals, Flyouts)
  - `border-subtle`: `rgba(255, 255, 255, 0.08)`
  - `border-active`: `rgba(99, 102, 241, 0.35)`
- **Contradiction Alert Ramp:** 
  - Subdued background: `rgba(245, 158, 11, 0.12)`
  - Border alert: `rgba(245, 158, 11, 0.40)`
  - Foreground text: `#FDE68A`

## Typography

Typography balances technical synthesis with executive scanning efficiency:

- **Headlines (Space Grotesk):** Provides structural, technical authority. Proportional numbers and geometric geometry reinforce speed and clarity in meeting titles, decision outcomes, and top-level navigation.
- **Body & Transcripts (Geist):** Clean, neutral, high-legibility sans-serif optimized for long-form speech transcripts, synthetic notes, and multi-line task summaries.
- **Metadata & Technical Indicators (JetBrains Mono):** Monospaced precision for timestamps (`00:14:32`), confidence scores (`98.4%`), speaker diarization tags (`[SPK_01]`), and cross-reference hashes between contradictory meeting logs.

## Layout & Spacing

The layout is built around high-density mobile viewports, shifting systematically across screen widths:

- **Mobile Viewport (up to 640px):** Single-column dynamic feed with 16px lateral margins (`margin`). Spacing uses a standard 4px/8px rhythm. Audio capture controls stick to a rigid bottom utility bar.
- **Tablet / Split Screen (641px - 1024px):** 6-column fluid structure allowing concurrent transcript review on the left and live contradictory conflict mapping on the right.
- **Desktop Dashboard (1025px+):** 12-column grid with fixed 280px left navigation rail, 24px margins, and variable multi-panel telemetry panes.

Transcripts and contradictory nodes leverage unified vertical padding (`space-md`) to ensure tap targets never drop below the accessible 44px threshold.

## Elevation & Depth

Visual hierarchy relies on calibrated surface luminescence and low-contrast perimeter barriers rather than heavy, drop-shadow blur filters:

- **Tonal Layers:** The screen rises from the background canvas (`#0B0F19`) to container surfaces (`#111827`) and elevated interactives (`#1E293B`).
- **Laser-Etched Outlines:** Cards and dialogs feature a sharp 1px border (`rgba(255, 255, 255, 0.08)`). Focused cards upgrade their border to primary indigo with an ambient glow (`box-shadow: 0 0 16px rgba(99, 102, 241, 0.15)`).
- **Glassmorphism in Transient States:** Persistent audio recording pill overlays and active conflict sheets employ backdrop blur filters (`backdrop-filter: blur(16px); background: rgba(17, 24, 39, 0.75)`).
- **Contradiction Illumination:** Conflicting decision cards project a localized amber rim highlight (`box-shadow: inset 0 0 0 1px rgba(245, 158, 11, 0.4), 0 4px 20px -2px rgba(245, 158, 11, 0.15)`).

## Shapes

The design system applies a **Rounded (Level 2)** geometry balance:

- **Standard Containers & Cards:** `0.5rem` (8px) corners convey modern structural discipline and technical reliability.
- **Modals, Sheets & Flyouts:** `1rem` (16px) radius softens contextual mobile overlays without losing architectural crispness.
- **Action Pills, Badges & Voice Waveform Wrappers:** `9999px` fully rounded pills isolate micro-metadata, recording indicators, and contradiction severity pills.

## Components

### Buttons & Interactive Controls
- **Primary Action (Record, Commit Decision):** High-saturation Indigo background (`#6366F1`), white text (`#FFFFFF`), micro-radiused (`8px`). Subtle inner highlight along the top border.
- **Neural Synth Button (AI Generate, Summarize):** Deep violet tint with dynamic shifting gradient border (`#A855F7` to `#6366F1`).
- **Ghost/Tertiary:** Transparent fill with `rgba(255, 255, 255, 0.08)` border; text resolves to neutral light slate (`#E2E8F0`).

### Contradiction Detection Badges
- Constructed with a distinct pill structure: `JetBrains Mono` bold uppercase text, glowing amber point beacon (`#F59E0B`), and contrasting background (`rgba(245, 158, 11, 0.12)`).
- In expanded mode, contradiction badges show a split view: Previous Decision vs. New Decision with visual delta links.

### Audio Waveform & Meeting Capture Bar
- Fixed floating docked capsule anchored to the mobile base. Uses glassmorphic blur (`backdrop-filter: blur(20px)`), an active animated equalizer bar (Indigo + Violet), duration counter in `JetBrains Mono`, and immediate tactile stop/pause inputs.

### Decision Cards & Action Item Assignees
- Clean cards featuring 1px subtle borders. Tasks contain inline user avatar micro-pills, confidence percentage chips, direct calendar export toggles, and editable completion criteria.
- Conflicts embedded within decision cards display a left accent rail (3px solid `#F59E0B`).

### Form Inputs & Filters
- Inset dark background (`#0B0F19`), 1px outline (`#334155`). Upon focus, morphs to `#6366F1` with zero interior displacement. Placeholder labels utilize muted neutral slate (`#64748B`).